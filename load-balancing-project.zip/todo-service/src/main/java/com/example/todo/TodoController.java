package com.example.todo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/todos")
public class TodoController {
 @Value("${server.port}") private String port;

 @GetMapping
 public String getTodos() {
   return "Hello from Todo Service instance running on port " + port;
 }

 @GetMapping("/{id}")
 public String getTodo(@PathVariable Long id) {
   return "Todo " + id + " served by instance on port " + port;
 }
}