# Spring Boot Load Balancing Demo

Projects:
- eureka-server :8761
- api-gateway :8080
- todo-service :8081 / 8082

Run Eureka first, then two Todo Service instances, then Gateway.

Test:
GET http://localhost:8080/todos

The response shows which Todo Service instance handled the request.
